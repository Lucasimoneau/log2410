/****************************************************************************
**
** Classe TeamMember
** Author: p482457
** Date: 25-oct-2019
**
****************************************************************************/

#include "TeamMember.h"

// Define class static members
TeamComponentContainer TeamMember::m_emptyContainer;

TeamMember::TeamMember(std::string name, const QImage & photo)
{
	//  Completer

	m_image = photo;
	m_name = name;

}

TeamMember::TeamMember(const TeamMember & mdd)
{
	//  Completer: constructeur de copie

	m_image = mdd.getImage();
	m_name = mdd.getName();
}

TeamMember * TeamMember::clone(void) const
{
	//  Completer (cr�er un nouvel objet identique a this)

	return new TeamMember(*this);
}

const QImage & TeamMember::getImage(void) const
{
	//  Completer

	return m_image;
}

QImage & TeamMember::getImage(void)
{
	//  Completer

	return m_image;
}

std::string TeamMember::getName(void) const
{
	//  Completer

	return m_name;
}

void TeamMember::setName(std::string name)
{
	//  Completer

	m_name = name;
}

AbsTeamComponent& TeamMember::addTeamComponent(const AbsTeamComponent&)
{
    // Truc pour que le code compile. Rien � changer
	return *(*(m_emptyContainer.begin()));
}

TeamComponentIterator TeamMember::begin()
{
	//  Completer

	return m_emptyContainer.begin();
}

TeamComponentIterator_const TeamMember::cbegin() const
{
	//  Completer

	return m_emptyContainer.cbegin();
}

TeamComponentIterator_const TeamMember::cend() const
{
	//  Completer

	return m_emptyContainer.cend();
}

TeamComponentIterator TeamMember::end()
{
	//  Completer

	return m_emptyContainer.end();
}

void TeamMember::deleteTeamComponent(TeamComponentIterator_const)
{
	// Rien a faire, un membre ne peut pas avoir d'enfants
}

