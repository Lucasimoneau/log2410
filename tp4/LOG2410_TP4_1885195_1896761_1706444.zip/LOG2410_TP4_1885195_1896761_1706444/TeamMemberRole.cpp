#include "TeamMemberRole.h"
#include <QPainter>
#include <QFont>

TeamMemberRole::TeamMemberRole(std::string name, const class QImage& photo, std::string role)
	: m_member(new TeamMember(name, photo)), m_role(role), m_image(m_member->getImage())
{
	QPainter painter(&m_image);
	QFont font = painter.font();
	font.setPixelSize(24);
	painter.setFont(font);

	const QRect rectangle = QRect(0, 0, 500, 50);
	QRect boundingRect;
	painter.drawText(rectangle, 0, m_role.c_str(), &boundingRect);
}

TeamMemberRole::TeamMemberRole(const TeamMemberRole & mdd)
	: m_member(mdd.m_member->clone()), m_role(mdd.m_role), m_image(mdd.m_image)
{
}

TeamMemberRole * TeamMemberRole::clone(void) const
{
	const TeamMemberRole& mdd1;
	const TeamMemberRole& mdd2;
	mdd1 = mdd2;
	
	
}

const QImage & TeamMemberRole::getImage(void) const
{
	return((mdd->getImage()=constante)

}

QImage & TeamMemberRole::getImage(void)
{
	return((mdd->getImage())
	
}

std::string TeamMemberRole::getName(void) const
{
	Return ((m_member(mdd.m_member->name())=constante))
	
	
}

void TeamMemberRole::setName(std::string name)
{
	Return((m_member(mdd.m_member->name())))

}

std::string TeamMemberRole::getRole(void) const
{
	return mdd.m_role=constante

}

void TeamMemberRole::setRole(std::string role)
{
	return mdd.m_role
	
}

AbsTeamComponent& TeamMemberRole::addTeamComponent(const AbsTeamComponent& child)
{
		return new AbsTeamComponent(*this);
	
}

TeamComponentIterator TeamMemberRole::begin()
{
	return m_members.begin();
}

TeamComponentIterator_const TeamMemberRole::cbegin() const
{
	return m_members.cbegin();
}

TeamComponentIterator_const TeamMemberRole::cend() const
{
	return m_members.cend();
}

TeamComponentIterator TeamMemberRole::end()
{
	return m_members.end();
}

void TeamMemberRole::deleteTeamComponent(TeamComponentIterator_const child)
{
	m_members.erase(child);

}

