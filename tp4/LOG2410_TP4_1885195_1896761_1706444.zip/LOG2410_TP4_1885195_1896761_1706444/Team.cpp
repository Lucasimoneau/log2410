#include "Team.h"

Team::Team(std::string name)
{
	//  Completer

	m_name = name;
}

Team::Team(const Team & mdd)
{
	//  Completer (constructeur de copie)

	m_name = mdd.getName();
}

Team * Team::clone(void) const
{
	//  Completer (cr�er un nouvel objet identique a this)

	return new Team(*this);
}

const QImage & Team::getImage(void) const
{
	

	return m_image;
}

QImage & Team::getImage(void)
{


	return m_image;
}

std::string Team::getName(void) const
{


	return m_name;
}

void Team::setName(std::string name)
{


	m_name = name;
}

AbsTeamComponent& Team::addTeamComponent(const AbsTeamComponent & member)
{
	// A Completer: Ajouter un nouvel element dans la liste et le clonant et
	// retrourner une reference a l'objet insere dans la liste

	AbsTeamComponent* newMember = member.clone();
	m_members.push_back(TeamComponentPtr(newMember));

	return *newMember;
}

TeamComponentIterator Team::begin()
{


	return m_members.begin();
}

TeamComponentIterator_const Team::cbegin() const
{


	return m_members.cbegin();
}

TeamComponentIterator_const Team::cend() const
{


	return m_members.cend();
}

TeamComponentIterator Team::end()
{


	return m_members.end();
}

void Team::deleteTeamComponent(TeamComponentIterator_const child)
{

	m_members.erase(child);
}

void Team::deleteAllComponents(void)
{

	m_members.clear();
}
